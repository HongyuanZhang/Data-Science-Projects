# CSC-207 (Fall 2017, Section 1) Homework 5: The Sounds of Sorting

[The Sounds of Sorting](http://www.cs.grinnell.edu/~osera/courses/csc207/17sp/homeworks/the-sounds-of-sorting.html)

### Implements a visualizer and audibilizer for 5 different sorting algorithms

* *Authors:* Hongyuan Zhang and Khoa Ho
* *Emails:* [zhanghon] and [hokhoa]
