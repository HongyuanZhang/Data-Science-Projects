# CSC 161 (Spring 2016, Section 01) Project 7: Scribbler Parade

Please edit this README file with your group members' names and Grinnell IDs along with citations of any sources you used in completing this project.

Hongyuan Zhang Kohei Kotani
[zhanghon] [kotaniko]