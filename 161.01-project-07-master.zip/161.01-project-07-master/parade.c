#include <time.h>
#include <stdio.h>
#include <MyroC.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void initial_move(void) {
  char x = '\0';
  while(x == '\0') {
    printf("Please press any key to prepare your car to begin.\n");
    scanf("%c", &x);
    if(x != '\0') {
      rMotors(0.25, 0.25);
    }
  }
}

void logging(FILE* logname, char* command) {
  time_t rawtime;
  char time_str[25];
  time(&rawtime);
  ctime(&rawtime);
  strncpy(time_str, ctime(&rawtime), 24);
  if (logname == NULL) { return; }
  double average_brightness = (rGetLightTxt("left", 5) + rGetLightTxt("right", 5) + rGetLightTxt("middle", 5)) / 3.0;
  fprintf(logname, "%s %s (%d, %d, %f)\n",time_str, command, rGetIRTxt("left", 5), rGetIRTxt("right", 5), average_brightness);
}

void formal_start(FILE* filename, FILE* logname) {
  char x = '\0';
  while(x == '\0') {
    printf("Please press any key to begin the parade formally.\n");
    scanf("%c", &x);
    if(x != '\0') {
      rStop();
      char buff[30];
      while(fgets(buff, sizeof(buff), filename) != NULL) {       
        char* command = strtok(buff, " ");
        //Forward
        if (!strncmp(command, "forward", 7)) {
          double time = atof(strtok(NULL, " "));
          logging(logname, command);
          rForward(1.0, time);
          //Turn
        } else if (!strncmp(command, "turn", 4)) {
          int degrees = atoi(strtok(NULL, " "));
          char* direction = strtok(NULL, " ");
          logging(logname, command);
          if (!strncmp(direction, "right", 5)) {
            if (degrees == 45) {
              rTurnRight(1.0, 0.4);
            } else if (degrees == 90) {
              rTurnRight(1.0, 0.8);
            } else {
              printf("Invalid degrees. Only 45 or 90 degrees are valid.\n");
            }
          } else if (!strncmp(direction, "left", 4)) {
            if (degrees == 45) {
              rTurnLeft(1.0, 0.4);
            } else if (degrees == 90) {
              rTurnLeft(1.0, 0.8);
            } else {
              printf("Invalid degrees. Only 45 or 90 degrees are valid.\n");
            }        
          } else {
            printf("Invalid direction. Only left or right is valid.\n");
          }
          //Spin
        } else if (!strncmp(command, "spin", 4)) {
          char* direction = strtok(NULL, " ");
          logging(logname, command);
          if (!strncmp(direction, "right", 5)) {
            rMotors(-1.0, 1.0);
            sleep(3.99);
            rStop();
          } else if (!strncmp(direction, "left", 4)) {
            rMotors(1.0, -1.0);
            sleep(3.99);
            rStop();
          } else {
             printf("Invalid direction. Only left or right is valid.\n");
          }
          //Beep
        }  else if (!strncmp(buff, "beep", 4)) {
          //get rid of the newline character at the end of "command"
          command = "beep";
          logging(logname, command);
          rBeep(1.0, 698);
          //Ditty
        } else if (!strncmp(buff, "ditty", 5)) {
          //get rid of the newline character at the end of "command"
          command = "ditty";
          logging(logname, command);
          for (int i =0; i < 5; i++) {
            rBeep(0.2, 800 + 30 * i);
          }
          //Song
        } else if (!strncmp(buff, "song", 4)) {
          //get rid of the newline character at the end of "command"
          command = "song";
          logging(logname, command);
          for (int i =0; i < 10; i++) {
            rBeep(0.2, 600 + 30 * i);
            rBeep(0.1, 600 - 30 * i);
          }
        } else {
          printf("Command does not exist. Only the following commands are valid: forward, turn, spin, beep, ditty and song.\n");
        }
      }
    }
  }
}

void graceful_exit(void) {
  rForward(1.0, 2.0);
  for (double i = 1.0; i > 0; i -= 0.2) {
    rForward(i, 1.0);
  }
}

int main(int argc, char **argv) {
  FILE *scriptname, *logname;
  rConnect("/dev/rfcomm0");
  if (argc == 2) {
    scriptname = fopen(argv[1], "r");
    logname = NULL;
  } else if (argc == 4) {
    scriptname = fopen(argv[3], "r");
    logname = fopen(argv[2], "w");
  } else if (argc == 1 || argc == 3) {
    printf("No script files. Please add a script file.\n");
    return 0;
  }
  initial_move();
  formal_start(scriptname, logname);
  graceful_exit();
  fclose(scriptname);
  if(logname != NULL) {
    fclose(logname);
  }
  rDisconnect;
  return 0;
}
